import Vue from 'vue'
import VueRouter, { RouteConfig } from 'vue-router'
import HomeView from '../views/HomeView.vue'
import ShopCart from '@/views/ShopCart.vue'
import Grzx from '@/views/Grzx.vue'
import SearchView from '../components/SearchView.vue';
import Auth from '@/components/Auth.vue';
import Favorites from '@/components/Favorites.vue'
import EditProfile from '@/components/EditProfile.vue'
import Paid from '@/components/Paid.vue'
import Admin from '@/components/Admin.vue'
import Commodity from '@/components/Commodity.vue'
Vue.use(VueRouter)

const routes: Array<RouteConfig> = [
  {
    path: '/',
    name: 'home',
    component: HomeView,
  },   
  {
    path: '/search',
    name: 'SearchView',
    component: SearchView,
  },
  {
    path: '/shopcart',
    name: 'ShopCart',
    component: ShopCart
  },
  {
    path: '/grzx',
    name: 'Grzx',
    component: Grzx
  },
  {
    path: '/auth',
    name: 'Auth',
    component: Auth,
  },{
    path: '/favorites',
    name: 'Favorites',
    component: Favorites
  },
  {
    path: '/editprofile',
    name: 'EditProfile',
    component: EditProfile
  },
  {
    path: '/paid',
    name: 'Paid',
    component: Paid
  },
  {
    path: '/admin',
    name: 'Admin',
    component: Admin
  },
  {
    path: '/commodity',
    name: 'Commodity',
    component: Commodity
  }
]

const router = new VueRouter({
  routes
})

export default router
