<template>
  <div>
    <h1><router-link to="/admin" class="nav-link">用户管理</router-link> /
        <router-link to="/commodity" class="nav-link">商品管理</router-link></h1>
    <table border="1">
      <thead>
        <tr>
          <th>ID</th>
          <th>名称</th>
          <th>价格</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="commodity in commodities" :key="commodity.id">
          <td>{{ commodity.id }}</td>
          <td v-if="editingCommodity && editingCommodity.id === commodity.id">
            <input v-model="editingCommodity.name" type="text" />
          </td>
          <td v-else>{{ commodity.name }}</td>
          <td v-if="editingCommodity && editingCommodity.id === commodity.id">
            <input v-model="editingCommodity.price" type="text" />
          </td>
          <td v-else>{{ commodity.price }}</td>
          <td>
            <button
              v-if="
                !isEditing ||
                (editingCommodity && editingCommodity.id !== commodity.id)
              "
              @click="deleteCommodity(commodity.id)"
            >
              删除
            </button>
            <button
              v-if="!editingCommodity || editingCommodity.id !== commodity.id"
              @click="editCommodity(commodity)"
            >
              编辑
            </button>
            <button
              v-if="editingCommodity && editingCommodity.id === commodity.id"
              @click="saveCommodity"
            >
              保存
            </button>
            <button
              v-if="editingCommodity && editingCommodity.id === commodity.id"
              @click="cancelEdit"
            >
              取消
            </button>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>
  
  <script>
import axios from "axios";

export default {
  data() {
    return {
      commodities: [],
      editingCommodity: null, // 当前正在编辑的商品
      isEditing: false, // 是否处于编辑状态
    };
  },
  methods: {
    async fetchCommodities() {
      try {
        const response = await axios.get(
          "http://localhost:3006/api/commodities"
        );
        this.commodities = response.data;
      } catch (error) {
        console.error("Error fetching commodities:", error);
      }
    },
    async deleteCommodity(commodityId) {
      try {
        await axios.delete(
          `http://localhost:3006/api/commodities/${commodityId}`
        );
        this.fetchCommodities(); // 删除成功后重新获取数据
      } catch (error) {
        console.error("Error deleting commodity:", error);
      }
    },
    editCommodity(commodity) {
      // 进入编辑模式
      this.editingCommodity = { ...commodity }; // 深拷贝当前商品数据
      this.isEditing = true; // 设置为编辑状态
    },
    async saveCommodity() {
      try {
        // 确保使用 editingCommodity 而不是 commodity
        await axios.put(
          `http://localhost:3006/api/commodities/${this.editingCommodity.id}`,
          {
            name: this.editingCommodity.name,
            price: this.editingCommodity.price,
          }
        );
        this.fetchCommodities();
        this.cancelEdit();
      } catch (error) {
        console.error("Error saving commodity:", error);
      }
    },
    cancelEdit() {
      this.editingCommodity = null; // 清空编辑状态
      this.isEditing = false; // 退出编辑状态
    },
  },
  mounted() {
    this.fetchCommodities();
  },
};
</script>
  
  <style scoped>
table {
  width: 100%;
  border-collapse: collapse;
}

th,
td {
  padding: 8px;
  text-align: left;
  border-bottom: 1px solid #ddd;
}

input {
  width: 100%;
  padding: 5px;
  box-sizing: border-box;
}

button {
  background-color: #f44336;
  color: white;
  border: none;
  padding: 5px 10px;
  cursor: pointer;
  margin-right: 5px; /* 增加按钮之间的间距 */
}

button:hover {
  background-color: #d32f2f;
}

button.edit-button {
  background-color: #4caf50; /* 编辑按钮使用不同的颜色 */
}

button.edit-button:hover {
  background-color: #45a049;
}
</style>