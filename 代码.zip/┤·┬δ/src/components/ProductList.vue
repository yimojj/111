<template>
  <div>
    <!-- 横向分类列表 -->
    <div class="category-list">
      <CategoryList @category-selected="filterByCategory" />
    </div>
    <div class="tb"></div>

    <!-- 商品卡片列表 -->
    <CommodityList :filteredCommodities="filteredCommodities" @add-to-cart="addToCart" @toggle-favorite="toggleFavorite" />
  </div>
</template>

<script>
import axios from 'axios';
import CategoryList from './CategoryList.vue';
import CommodityList from './CommodityList.vue';

export default {
  components: {
    CategoryList,
    CommodityList,
  },
  data() {
    return {
      commodities: [],
      selectedCategoryId: null,
    };
  },
  computed: {
    filteredCommodities() {
      if (!this.selectedCategoryId) {
        return this.commodities; // 没有选择分类时，返回所有商品
      }
      return this.commodities.filter(commodity => commodity.category_id === this.selectedCategoryId);
    },
  },
  mounted() {
    this.fetchCommodities(); // 初始获取所有商品
  },
  methods: {
    async fetchCommodities() {
      try {
        const response = await axios.get('http://localhost:3006/api/commodities', {
          params: {
            category: this.selectedCategoryId !== null ? this.selectedCategoryId : undefined,
          },
        });
        this.commodities = response.data; // 更新商品列表
        console.log('商品数据:', this.commodities);
      } catch (error) {
        console.error('无法获取商品数据:', error);
      }
    },
    filterByCategory(category_id) {
      this.selectedCategoryId = category_id;
      this.fetchCommodities(); // 根据选择的分类重新获取商品
    },
    addToCart(commodity) {
      console.log('添加到购物车:', commodity);
      // 处理添加到购物车的逻辑
    },
    toggleFavorite(commodity) {
      console.log('收藏/取消收藏:', commodity);
      // 处理收藏逻辑
    },
  },
};
</script>

<style scoped>
.category-list {
  position: fixed;
  z-index: 10;
  width: 530px;
  top: 80px;
}

.tb {
  height: 180px;
  width: 530px;
  background-color: #f5f5f5;
  position: fixed;
  z-index: 9;
  top: -20px;
}

</style>

