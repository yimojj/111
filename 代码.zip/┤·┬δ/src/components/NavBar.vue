<!-- NavBar.vue -->
<template>
    <nav >
      <router-link to="/">主页</router-link>
      <router-link to="/shopcart">购物车</router-link>
      <router-link to="/grzx">个人中心</router-link>
    </nav>
  </template>
  
  <script>
  export default {
    name: 'NavBar'
  }
  </script>
  
  <style scoped>
  nav {
    display: flex;
    justify-content: space-around;
    padding: 10px;
    position: fixed;
    z-index: 10;
    width: 510px;
    bottom: 0;
    background-color: #f8f8f8;
  }
  
  nav a {
    text-decoration: none;
    color: #333;
    font-weight: bold;
  }
  
  nav a.router-link-exact-active {
    color: #42b983;
  }
  </style>