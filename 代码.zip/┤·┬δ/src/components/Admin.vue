<template>
    <div class="user-container">
      <h1><router-link to="/admin" class="nav-link">用户管理</router-link> /
        <router-link to="/commodity" class="nav-link">商品管理</router-link></h1>
      <ul v-if="users.length">
        <li v-for="user in users" :key="user.id" class="user-item">
          <span>{{ user.username }}</span>
          <button @click="confirmDelete(user.user_id)" class="remove-btn">移除</button>
        </li>
      </ul>
      <p v-else>没有用户数据</p>
  
      <!-- 删除成功提示 -->
      <div v-if="showSuccessAlert" class="success-alert">
        <p>用户已成功移除！</p>
        <button @click="closeAlert" class="close-alert-btn">关闭</button>
      </div>
    </div>
  </template>
  
  <script setup>
  import { ref, onMounted } from 'vue';
  import axios from 'axios';
  
  const users = ref([]);
  const showSuccessAlert = ref(false);
  
  const fetchUsers = async () => {
    try {
      const response = await axios.get('http://localhost:3006/api/user');
      users.value = response.data.users;
    } catch (error) {
      console.error('获取用户数据失败:', error);
    }
  };
  
  const confirmDelete = (userId) => {
    // 弹出确认框
    if (confirm("你确定要移除该用户吗？")) {
      deleteUser(userId);
    }
  };
  
  const deleteUser = async (userId) => {
    try {
      await axios.delete(`http://localhost:3006/api/user/${userId}`);
      fetchUsers(); // 删除成功后重新获取用户数据
      showSuccessAlert.value = true; // 显示删除成功提示
    } catch (error) {
      console.error('删除用户失败:', error);
    }
  };
  
  const closeAlert = () => {
    showSuccessAlert.value = false; // 关闭删除成功提示
  };
  
  onMounted(() => {
    fetchUsers();
  });
  </script>
  
  <style scoped>
  /* 基本样式 */
  .user-container {
    max-width: 500px;
    margin: 0 auto;
    padding: 20px;
    border: 1px solid #ccc;
    border-radius: 5px;
    background-color: #ffffff; /* 背景颜色 */
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1); /* 阴影 */
  }
  
  h1 {
    text-align: center;
    color: #333;
  }
  
  ul {
    list-style-type: none;
    padding: 0;
  }
  
  .user-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin: 10px 0;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
    background-color: #f9f9f9; /* 条目的背景色 */
    transition: background-color 0.3s; /* 平滑过渡 */
  }
  
  .user-item:hover {
    background-color: #f1f1f1; /* 悬停效果 */
  }
  
  .remove-btn {
    background-color: #ff6347; /* 番茄红 */
    color: white;
    border: none;
    padding: 5px 10px;
    border-radius: 4px;
    cursor: pointer;
    transition: background-color 0.3s; /* 按钮平滑过渡 */
  }
  
  .remove-btn:hover {
    background-color: #e05133; /* 更深的红色 */
  }
  
  /* 删除成功提示框样式 */
  .success-alert {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 20px;
    background-color: #dff2bf; /* 浅绿色 */
    color: #3c763d;
    border: 1px solid #a5d6a7;
    border-radius: 4px;
    margin-top: 10px;
  }
  
  .close-alert-btn {
    background-color: #3c763d; /* 绿色 */
    color: white;
    border: none;
    border-radius: 4px;
    cursor: pointer;
    padding: 5px 10px;
  }
  
  .close-alert-btn:hover {
    background-color: #357a38; /* 深绿色 */
  }
  </style>