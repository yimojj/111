<template>
  <div class="kt">
    <!-- 商品卡片列表 -->
    <ul class="commodity-list">
      <li v-for="commodity in filteredCommodities" :key="commodity.id" class="commodity-card">
        <!-- 商品图片 -->
        <img :src="commodity.image" alt="商品图片" class="commodity-image">
        <!-- 商品信息 -->
        <div class="commodity-info">
          <div class="commodity-name">{{ commodity.name }}</div>
          <div class="commodity-price">￥{{ commodity.price}}</div>
          <div class="commodity-sales">销量: {{ commodity.sales }}</div>
          <div class="commodity-tag" v-if="commodity.special_activity_name">{{ commodity.special_activity_name }}</div>
          <!-- 购物车和收藏图标 -->
          <div class="commodity-actions">
            <span class="icon-cart" @click="handleAddToCart(commodity)">&#128722;</span>
            <span class="icon-favorite" @click="toggleFavorite(commodity)">&#10084;</span>
          </div>
        </div>
      </li>
    </ul>
    <!-- 没有商品的提示 -->
    <div v-if="filteredCommodities.length === 0">没有找到商品</div>
  </div>
</template>
  
<script>
import axios from 'axios';

export default {
  props: {
    filteredCommodities: {
      type: Array,
      required: true,
    },
  },
  methods: {
    async handleAddToCart(commodity) {
      if (!this.userId) {
        alert("请先登录！");
        return;
      }
      try {
        // 使用 axios 发送请求，将商品添加至购物车
        const response = await axios.post(
          "http://localhost:3006/api/user/add-to-cart",
          {
            userId: this.userId, // 用户ID
            commodityId: commodity.id, // 商品ID
            quantity: 1, // 数量（默认添加1个）
          }
        );
        
        if (response.status === 200) {
          alert("商品已成功加入购物车！");
        } else {
          alert("添加至购物车失败，请重试。");
        }
      } catch (error) {
        alert("添加至购物车失败，请重试。");
        console.error("添加商品到购物车失败:", error);
      }
    },
    async toggleFavorite(commodity) {
      if (!this.userId) {
        alert("请先登录！");
        return;
      }

      const isFavorite = this.isCommodityInFavorites(commodity.id);
      const confirmMessage = isFavorite ? "确定要取消收藏吗？" : "确定要加入收藏吗？";

      if (!confirm(confirmMessage)) {
        return;
      }

      try {
        const url = isFavorite 
          ? `http://localhost:3006/api/user/unfavorite` 
          : `http://localhost:3006/api/user/favorite`;

        const response = await axios.post(
          url,
          {
            userId: this.userId, // 用户ID
            commodityId: commodity.id, // 商品ID
          }
        );

        if (response.status === 200) {
          alert(isFavorite ? "取消收藏成功！" : "加入收藏成功！");
          this.$emit('update-favorites', this.userId); // 通知父组件更新收藏列表
        } else {
          alert(isFavorite ? "取消收藏失败，请重试。" : "加入收藏失败，请重试。");
        }
      } catch (error) {
        alert(isFavorite ? "取消收藏失败，请重试。" : "加入收藏失败，请重试。");
        console.error(isFavorite ? "取消收藏失败:" : "加入收藏失败:", error);
      }
    },
    isCommodityInFavorites(commodityId) {
      const favorites = this.userInfo.favorites || [];
      return favorites.includes(commodityId);
    }
  },
  computed: {
    // 从 localStorage 读取用户信息
    userInfo() {
      try {
        const user = JSON.parse(localStorage.getItem("user"));
        return user || {}; // 如果用户信息为空，返回空对象
      } catch (error) {
        console.error("解析用户信息失败", error);
        return {};

        
      }
    },
    // 从 userInfo 中解构出 user_id
    userId() {
      return this.userInfo.user_id;
    },
  },
};
</script>
<style scoped>


/* 商品列表样式 */
.commodity-list {
  display: flex;
  flex-wrap: wrap; /* 允许多行排列 */
  gap: 20px; /* 商品卡片之间的间距 */
  background-color: #fbfbfb;
}
.kt {
  top:130px;
  position: relative;
}

/* 商品卡片样式 */
.commodity-card {
  display: flex;
  flex-direction: column;
  width: 180px; /* 卡片宽度 */
  height: 310px; /* 调整卡片高度 */
  border: 1px solid #ddd; /* 卡片边框 */
  border-radius: 8px; /* 圆角 */
  padding: 8px; /* 内边距 */
  box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1); /* 卡片阴影 */
  transition: transform 0.2s ease-in-out; /* 卡片悬停效果 */
}

.commodity-card:hover {
  transform: translateY(-3px); /* 卡片悬停时轻微上移 */
}

/* 商品图片样式 */
.commodity-image {
  width: 100%; /* 图片宽度自适应卡片 */
  height: 70%; /* 图片占卡片高度的70% */
  object-fit: cover; /* 图片填充方式 */
  border-radius: 4px; /* 图片圆角 */
  margin-bottom: 8px; /* 图片与信息的间距 */
}

/* 商品信息样式 */
.commodity-info {
  display: flex;
  flex-direction: column;
  justify-content: flex-start; /* 内容自上而下排列 */
  flex-grow: 1; /* 使内容区域占满剩余空间 */
  align-items: flex-start; /* 左对齐 */

}

/* 商品名称样式 */
.commodity-name {
  font-size: 14px;           /* 调整字体大小 */
  font-weight: bold;         /* 加粗字体 */
  margin: 4px 0;            /* 顶部和底部间距 */
  color: #333;               /* 文字颜色 */
  white-space: nowrap;       /* 文本不换行 */
  overflow: hidden;          /* 隐藏多余文本 */
  text-overflow: ellipsis;   /* 多余文本以省略号表示 */
  display: block;            /* 必须是 block 或 inline-block 才能使用 text-overflow */
  max-width: 100%;          /* 设置最大宽度为父元素宽度 */
}

/* 商品销量样式 */
.commodity-sales {
  font-size: 12px; /* 调整销量字体大小 */
  color: #888;
  margin-bottom: 8px; /* 底部间距 */
}

/* 特别标签样式 */
.commodity-tag {
  font-size: 12px;
  color: #fff;
  background-color: #ff6347; /* 标签背景颜色 */
  padding: 2px 4px;
  border-radius: 8px;
  text-align: center;
  width: fit-content;
}

/* 商品操作图标样式（购物车和收藏） */
.commodity-actions {
  display: flex;
  justify-content: space-between; /* 操作图标两端对齐 */
  margin-top: auto; /* 推到卡片底部 */
  position: relative;
    right: -130px;
}

.icon-cart, .icon-favorite {
  font-size: 18px; /* 调整图标大小 */
  cursor: pointer;
  color: #ff6347; /* 图标颜色 */
  transition: color 0.2s ease-in-out; /* 图标悬停颜色变化 */
}

.icon-cart:hover {
  color: #3e8e41; /* 购物车图标悬停颜色 */
}

.icon-favorite:hover {
  color: #e74c3c; /* 收藏图标悬停颜色 */
}

div:last-child {
  color: #ff4500;
  font-size: 16px;
  font-weight: bold;
}
</style>