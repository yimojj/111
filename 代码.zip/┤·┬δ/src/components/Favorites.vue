<template>
    <div class="favorites-container">
      <h2>我的收藏</h2>
  
      <!-- 收藏列表 -->
      <div v-if="commodities.length > 0">
        <div v-for="item in commodities" :key="item.id" class="favorite-item">
          <img :src="item.image" :alt="item.title" class="favorite-image" />
          <div class="favorite-info">
            <h3>{{ item.name }}</h3>
            <p>￥{{ item.price }}</p>
            <button @click="confirmRemove(item.id)" class="remove-button">
              移除
            </button>
            <button @click="addToCart(item.id, 1)" class="add-to-cart-button">
              <i class="fas fa-shopping-cart"></i> 添加至购物车
            </button>
          </div>
        </div>
      </div>
  
      <div v-else>
        <p>您还没有收藏任何内容。</p>
      </div>
  
      <button @click="goBack" class="back-button">返回个人中心</button>
    </div>
  </template>
  <script>
  import axios from "axios";
  
  export default {
    data() {
      return {
        commodities: [], // 商品列表（从服务器获取后填充）
        error: null, // 错误信息
      };
    },
    computed: {
      // 从 localStorage 读取用户信息
      userInfo() {
        try {
          const user = JSON.parse(localStorage.getItem("user"));
          return user || {}; // 如果用户信息为空，返回空对象
        } catch (error) {
          console.error("解析用户信息失败", error);
          return {};
        }
      },
      // 从 userInfo 中解构出 user_id
      userId() {
        return this.userInfo.user_id;
      },
      // 将 favorites 字符串转换为数组形式
      favorites() {
        return this.userInfo.favorites
          ? this.userInfo.favorites.split(",").map(Number)
          : [];
      },
    },
    mounted() {
      // 组件挂载后，获取用户收藏的商品列表
      this.fetchCommodities();
    },
    methods: {
      // 获取用户收藏的商品列表
      async fetchCommodities() {
        try {
          // 使用 GET 请求获取用户收藏的商品
          const response = await axios.get(
            "http://localhost:3006/api/user/favorites",
            {
              params: {
                userId: this.userId, // 传递用户ID作为查询参数
              },
            }
          );
          this.commodities = response.data; // 更新商品列表
        } catch (error) {
          this.error = "无法获取商品数据";
          console.error("无法获取商品数据:", error);
          alert("无法获取商品数据，请稍后重试。");
        }
      },
      // 确认移除收藏
      confirmRemove(commodityId) {
        if (confirm("确定要移除此商品吗？")) {
          this.removeFromFavorites(commodityId);
        }
      },
      // 移除收藏
      async removeFromFavorites(commodityId) {
        try {
          // 使用 axios 发送请求，从收藏中移除商品
          const response = await axios.post(
            "http://localhost:3006/api/user/unfavorite",
            {
              userId: this.userId, // 传递用户ID
              commodityId, // 传递要删除的商品ID
            }
          );
          if (response.status === 200) {
            // 成功移除后，更新本地收藏列表
            const updatedFavorites = this.favorites.filter(
              (id) => id !== commodityId
            );
  
            // 更新 localStorage 中的 favorites
            this.updateLocalStorageFavorites(updatedFavorites);
  
            // 更新组件内的商品列表
            this.commodities = this.commodities.filter(
              (item) => item.id !== commodityId
            );
  
            alert("商品已成功移除收藏。");
          } else {
            alert("移除收藏失败，请重试");
          }
        } catch (error) {
          alert("移除收藏失败，请重试");
          console.error("移除收藏失败:", error);
        }
      },
      // 添加商品到购物车
      async addToCart(commodityId, quantity) {
        try {
          // 使用 axios 发送请求，将商品添加至购物车
          const response = await axios.post(
            "http://localhost:3006/api/user/add-to-cart",
            {
              userId: this.userId, // 用户ID
              commodityId, // 商品ID
              quantity, // 数量
            }
          );
          
          if (response.status === 200) {
            alert("商品已成功加入购物车！");
          } else {
            alert("添加至购物车失败，请重试。");
          }
        } catch (error) {
          alert("添加至购物车失败，请重试。");
          console.error("添加商品到购物车失败:", error);
        }
      },
      // 更新 localStorage 中的 favorites
      updateLocalStorageFavorites(updatedFavorites) {
        // 获取当前用户信息
        const userInfo = this.userInfo;
        // 更新 favorites
        userInfo.favorites = updatedFavorites.join(",");
        // 保存到 localStorage
        localStorage.setItem("user", JSON.stringify(userInfo));
      },
      // 返回个人中心
      goBack() {
        this.$router.push("/grzx");
      },
    },
  };
  </script>
  
  <style scoped>
.favorites-container {
  padding: 20px;
}

.favorite-item {
  display: flex;
  margin-bottom: 20px;
}

.favorite-image {
  width: 100px;
  height: 100px;
  margin-right: 20px;
}

.favorite-info {
  flex: 1;
}

.favorite-item {
  display: flex;
  align-items: center;
  margin-bottom: 20px;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 5px;
}

.favorite-image {
  width: 100px;
  height: 100px;
  object-fit: cover;
  margin-right: 20px;
}

.favorite-info {
  flex: 1;
}

.remove-button,
.add-to-cart-button {
  padding: 10px 15px;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  margin-right: 10px;
}

.remove-button {
  background-color: #ff4d4d;
  color: white;
}

.add-to-cart-button {
  background-color: #4caf50;
  color: white;
}

.add-to-cart-button i {
  margin-right: 5px;
}

.remove-button {
  background-color: red;
  color: white;
  border: none;
  padding: 5px 10px;
  cursor: pointer;
}

.back-button {
  background-color: #42b983;
  color: white;
  border: none;
  padding: 10px 20px;
  cursor: pointer;
}
</style>