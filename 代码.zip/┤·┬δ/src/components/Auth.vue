<template>
  <div class="auth-container">
    <h2>{{ isLogin ? "登录" : "注册" }}</h2>
    <form @submit.prevent="handleSubmit">
      <input type="text" v-model="username" placeholder="用户名" required />
      <input type="password" v-model="password" placeholder="密码" required />
      <div v-if="!isLogin">
        <input
          type="password"
          v-model="confirmPassword"
          placeholder="确认密码"
          required
        />
      </div>
      <button type="submit">{{ isLogin ? "登录" : "注册" }}</button>
    </form>
    <p @click="toggleAuthMode">
      {{ isLogin ? "没有账号？点击这里注册" : "已有账号？点击这里登录" }}
    </p>
  </div>
</template>
  
  <script>
export default {
  data() {
    return {
      isLogin: true,
      username: "",
      password: "",
      confirmPassword: "",
    };
  },
  methods: {
    toggleAuthMode() {
      this.isLogin = !this.isLogin;
      // 清空输入框
      this.username = "";
      this.password = "";
      this.confirmPassword = "";
    },
    async handleSubmit() {
      const url = this.isLogin
        ? "http://localhost:3006/api/login"
        : "http://localhost:3006/api/register";
      const payload = {
        username: this.username,
        password: this.password,
      };

      if (!this.isLogin && this.password !== this.confirmPassword) {
        alert("两次密码输入不一致");
        return;
      }

      try {
        const response = await fetch(url, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(payload),
        });

        // 打印原始响应
        const textResponse = await response.text();
        console.log(textResponse); // 查看原始响应内容

        // 使用 try-catch 来处理 JSON 解析
        let data;
        try {
          data = JSON.parse(textResponse);
        } catch (err) {
          console.error("解析JSON失败:", err);
          alert("服务器返回的数据格式不正确");
          return;
        }

        if (response.ok) {
          alert(this.isLogin ? "登录成功" : "注册成功");

          // 使用 Vuex 更新用户状态
          this.$store.dispatch("login", data.user);

          // 保存用户信息到本地存储
          localStorage.setItem("user", JSON.stringify(data.user));
          localStorage.setItem("isLoggedIn", true);

          this.$router.push("/grzx");
        } else {
          alert(`错误: ${data.message}`);
        }
      } catch (error) {
        console.error("请求出错:", error);
        alert("请求失败，请稍后再试");
      }
    },
  },
};
</script>
  
  <style scoped>
.auth-container {
  width: 300px;
  margin: auto;
  padding: 20px;
  background-color: #fff;
  border-radius: 8px;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}
h2 {
  text-align: center;
}
input[type="text"],
input[type="password"] {
  width: 100%;
  padding: 10px;
  margin: 8px 0;
  border: 1px solid #ccc;
  border-radius: 4px;
}
button {
  width: 100%;
  padding: 10px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}
button:hover {
  background-color: #0056b3;
}
p {
  text-align: center;
  cursor: pointer;
  color: #007bff;
}
p:hover {
  text-decoration: underline;
}
</style>