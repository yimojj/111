<template>
  <div>
    <ul class="category-list">
      <li v-for="category in categories" :key="category.id" @click="selectCategory(category.id)" :class="{ selected: selectedCategory === category.id }">
        {{ category.name }}
      </li>
    </ul>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      categories: [],
      selectedCategory: null, // 用于存储当前选中的分类ID
    };
  },
  mounted() {
    this.fetchCategories();
  },
  methods: {
    async fetchCategories() {
      try {
        const response = await axios.get('http://localhost:3006/api/categories');
        this.categories = response.data;
      } catch (error) {
        console.error('无法获取类别数据:', error);
      }
    },
    selectCategory(categoryId) {
      this.selectedCategory = categoryId; // 更新当前选中的分类
      this.$emit('category-selected', categoryId);
    },
  },
};
</script>

<style scoped>
/* 横向分类列表样式 */
.category-list {
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
  overflow-x: auto; /* 允许水平滚动 */
  padding-bottom: 10px; /* 留出滚动条的空间 */
}

li {
  list-style: none;
  padding: 10px 20px;
  cursor: pointer;
  white-space: nowrap; /* 防止文本换行 */
}

li.selected {
  
  color: #1831dd;
    font-size: 120%;
    font-weight: bold;

}

/* 精选样式 */
.featured {
  font-weight: bold;
}
</style>