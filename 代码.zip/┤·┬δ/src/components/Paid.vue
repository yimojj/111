<template>
    <div id="app">
      <h1>{{ message }}</h1>
      <div v-if="isLoggedIn">
        <h2>
          <router-link to="/shopcart" class="nav-link">购物车信息</router-link> /
          <router-link to="/paid" class="nav-link">已支付订单</router-link>
        </h2>
        <div v-for="item in paidOrders" :key="item.id" class="card">
          <img :src="item.image" alt="商品图片" class="card-image">
          <div class="card-content">
            <h3>{{ item.name }}</h3>
            <p>价格: ¥{{ item.price }}</p>
            <p>数量: {{ item.quantity }}</p>
            <p>总花费: ¥{{ formatTotalCost(item.totalCost) }}</p>
          </div>
        </div>
      </div>
      <div v-else>
        <p>请先登录</p>
      </div>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    data() {
      return {
        user: null,
        paidOrders: [],
        message: '',
        isLoggedIn: false
      };
    },
    created() {
      this.checkLogin();
    },
    methods: {
      checkLogin() {
        const user = JSON.parse(localStorage.getItem('user'));
        if (user) {
          this.user = user;
          this.isLoggedIn = true;
          this.message = `欢迎回来，${user.username}！`;
          this.fetchPaidOrders(user.user_id);
        } else {
          this.message = '请先登录';
        }
      },
      async fetchPaidOrders(userId) {
        try {
          const response = await axios.get('http://localhost:3006/api/user/paid', {
            params: { userId }
          });
          this.paidOrders = response.data.map(item => ({
            ...item,
            totalCost: this.calculateTotalCost(item.price, item.quantity)
          }));
        } catch (error) {
          console.error('获取已支付订单信息失败:', error);
          this.message = '获取已支付订单信息失败。';
        }
      },
      calculateTotalCost(price, quantity) {
        return Number(price) * Number(quantity);
      },
      formatTotalCost(totalCost) {
        var totalCost = Number(totalCost.toFixed(2));
        return totalCost.toFixed(2);
      }
    }
  };
  </script>
  
  <style scoped>
  .card {
    display: flex;
    border: 1px solid #ccc;
    border-radius: 8px;
    padding: 16px;
    margin: 16px 0;
    max-width: 600px;
  }
  
  .card-image {
    width: 100px;
    height: 100px;
    object-fit: cover;
    margin-right: 16px;
  }
  
  .card-content {
    flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
  }
  
  .card-content h3 {
    margin: 0;
  }
  
  .card-content p {
    margin: 8px 0;
  }
  </style>