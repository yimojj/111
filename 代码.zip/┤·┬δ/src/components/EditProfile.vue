<template>
    <div class="update-user-info">
      <h2>修改用户信息</h2>
      <form @submit.prevent="updateUserInfo">
        <div class="form-group">
          <label for="username">用户名:</label>
          <input type="text" v-model="username" id="username" required />
        </div>
        <div class="form-group">
          <label for="password">密码:</label>
          <input type="password" v-model="password" id="password" required />
        </div>
        <button type="submit" class="btn-submit">提交修改</button>
      </form>
      <div v-if="message" :class="{ error: isError, success: !isError }">{{ message }}</div>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    data() {
      return {
        userId: '', // 用户ID
        username: '', // 用户名
        password: '', // 密码
        message: '', // 反馈信息
        isError: false // 是否是错误信息
      };
    },
    created() {
      // 组件创建时，从本地存储中获取用户信息
      const user = JSON.parse(localStorage.getItem('user'));
      if (user) {
        this.userId = user.user_id;
        this.username = user.username;
        this.password = user.password; 
      } else {
        this.message = '未找到用户信息';
        this.isError = true;
      }
    },
    methods: {
      async updateUserInfo() {
        try {
          // 发送PUT请求到后端，更新用户信息
          const response = await axios.put(`http://localhost:3006/api/user/${this.userId}`, {
            username: this.username,
            password: this.password
          });
  
          if (response.status === 200) {
            // 更新成功，更新本地存储中的用户信息
            const updatedUser = {
              user_id: this.userId,
              username: this.username,
              password: this.password // 同样，实际项目中应谨慎处理密码
            };
            localStorage.setItem('user', JSON.stringify(updatedUser));
  
            this.message = '用户信息更新成功';
            this.isError = false;
          }
        } catch (error) {
          this.message = error.response ? error.response.data.message : '更新失败';
          this.isError = true;
          console.error('Update user info error:', error);
        }
      }
    }
  };
  </script>
  
  <style scoped>
  .update-user-info {
    max-width: 400px;
    margin: 50px auto;
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 8px;
    box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
  }
  
  h2 {
    text-align: center;
    margin-bottom: 20px;
  }
  
  .form-group {
    margin-bottom: 15px;
  }
  
  label {
    display: block;
    margin-bottom: 5px;
    font-weight: bold;
  }
  
  input[type="text"],
  input[type="password"] {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 4px;
    font-size: 16px;
  }
  
  .btn-submit {
    width: 100%;
    padding: 10px;
    background-color: #007bff;
    color: white;
    border: none;
    border-radius: 4px;
    font-size: 16px;
    cursor: pointer;
  }
  
  .btn-submit:hover {
    background-color: #0056b3;
  }
  
  .error {
    color: red;
    text-align: center;
  }
  
  .success {
    color: green;
    text-align: center;
  }
  </style>