<template>
  <div class="search-container">
    <header class="search-header">
      <button @click="goToHomePage" class="home-button">返回</button>
      <input 
        type="text" 
        placeholder="搜索商品..." 
        v-model="searchQuery" 
        @input="fetchResults" 
        class="search-box"
      />
    </header>
    <div class="search-results">
      <div v-if="loading">加载中...</div>
      <div v-else-if="results.length === 0">没有找到商品</div>
      <ul class="card-list">
        <li v-for="item in results" :key="item.id" class="card-item">
          <div class="card-image">
            <img :src="item.image" alt="商品图片" />
          </div>
          <div class="card-content">
            <h3 class="card-title">{{ item.name }}</h3>
            <p class="card-price">￥ {{ item.price }}</p>
            <p class="card-sales">销量: {{ item.sales }}</p>
            <p class="card-activity" v-if="item.special_activity_name">{{ item.special_activity_name }}</p>
            <div class="commodity-actions">
              <span class="icon-cart" @click="handleAddToCart(item)">&#128722;</span>
              <span class="icon-favorite" @click="toggleFavorite(item)">&#10084;</span>
            </div>
          </div>
        </li>
      </ul>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  name: 'SearchView',
  data() {
    return {
      searchQuery: '',
      results: [],
      loading: false,
    };
  },
  methods: {
    async fetchResults() {
      if (this.searchQuery.length === 0) {
        this.results = [];
        return;
      }
      
      this.loading = true;
      try {
        console.log('搜索词:', this.searchQuery); // 输出当前搜索词
        const response = await axios.get('http://localhost:3006/api/commodities', {
          params: {
            name: this.searchQuery, // 发送当前搜索词
          },
        });
        this.results = response.data; // 更新商品列表
        console.log('商品数据:', this.results); // 输出获取的商品数据
      } catch (error) {
        console.error('无法获取商品数据:', error);
      } finally {
        console.log('最终商品结果:', this.results); // 最终结果查看
        this.loading = false;
      }
    },
    goToHomePage() {
      this.$router.push('/'); // 假设主页的路径是 '/'
    },
    async handleAddToCart(commodity) {
      if (!this.userId) {
        alert("请先登录！");
        return;
      }
      try {
        // 使用 axios 发送请求，将商品添加至购物车
        const response = await axios.post(
          "http://localhost:3006/api/user/add-to-cart",
          {
            userId: this.userId, // 用户ID
            commodityId: commodity.id, // 商品ID
            quantity: 1, // 数量（默认添加1个）
          }
        );
        
        if (response.status === 200) {
          alert("商品已成功加入购物车！");
        } else {
          alert("添加至购物车失败，请重试。");
        }
      } catch (error) {
        alert("添加至购物车失败，请重试。");
        console.error("添加商品到购物车失败:", error);
      }
    },
    async toggleFavorite(commodity) {
      if (!this.userId) {
        alert("请先登录！");
        return;
      }

    const isFavorite = this.isCommodityInFavorites(commodity.id);
    const confirmMessage = isFavorite ? "确定要取消收藏吗？" : "确定要加入收藏吗？";

    if (!confirm(confirmMessage)) {
      return;
    }

    try {
      const url = isFavorite 
        ? `http://localhost:3006/api/user/unfavorite` 
        : `http://localhost:3006/api/user/favorite`;

      const response = await axios.post(
        url,
        {
          userId: this.userId, // 用户ID
          commodityId: commodity.id, // 商品ID
        }
      );

      if (response.status === 200) {
        // 更新本地存储的用户数据
        this.updateLocalFavorites(commodity.id, isFavorite);

        alert(isFavorite ? "取消收藏成功！" : "加入收藏成功！");
        this.$emit('update-favorites', this.userId); // 通知父组件更新收藏列表
      } else {
        alert(isFavorite ? "取消收藏失败，请重试。" : "加入收藏失败，请重试。");
      }
    } catch (error) {
      alert(isFavorite ? "取消收藏失败，请重试。" : "加入收藏失败，请重试。");
      console.error(isFavorite ? "取消收藏失败:" : "加入收藏失败:", error);
    }
  },
  isCommodityInFavorites(commodityId) {
    const favorites = this.userInfo.favorites || [];
    return favorites.includes(commodityId);
  },
  updateLocalFavorites(commodityId, isFavorite) {
    const favorites = this.userInfo.favorites || [];
    if (isFavorite) {
      // 取消收藏
      const updatedFavorites = favorites.filter(id => id !== commodityId);
      this.updateUserInfo({ ...this.userInfo, favorites: updatedFavorites });
    } else {
      // 加入收藏
      const updatedFavorites = [...favorites, commodityId];
      this.updateUserInfo({ ...this.userInfo, favorites: updatedFavorites });
    }
  },
  updateUserInfo(newUserInfo) {
    localStorage.setItem("user", JSON.stringify(newUserInfo));
    this.$forceUpdate(); // 强制更新组件以反映最新的用户信息
  }
},
computed: {
  // 从 localStorage 读取用户信息
  userInfo() {
    try {
      const user = JSON.parse(localStorage.getItem("user"));
      return user || {}; // 如果用户信息为空，返回空对象
    } catch (error) {
      console.error("解析用户信息失败", error);
      return {};
    }
  },
  // 从 userInfo 中解构出 user_id
  userId() {
    return this.userInfo.user_id;
  },
  },
};
</script>
  <style scoped>
  .search-container {
    padding: 20px;
  }
  .search-header {
    display: flex;
    align-items: center;
    margin-bottom: 20px;
  }
  .search-box {
    flex-grow: 1;
    padding: 10px;
    font-size: 16px;
  }
  .home-button {
    margin-right: 10px;
    padding: 10px 15px;
    border: none;
    border-radius: 4px;
    background-color: #007bff;
    color: white;
    cursor: pointer;
  }
  .home-button:hover {
    background-color: #0056b3;
  }
  .search-results {
    list-style: none;
    padding: 0;
  }
  .card-list {
    display: flex;
    flex-wrap: wrap;
    gap: 20px;
  }
  .card-item {
    display: flex;
    border: 1px solid #ccc;
    border-radius: 8px;
    overflow: hidden;
    width: 100%;
    max-width: 400px;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
  }
  .card-image img {
    width: 100px;
    height: 100px;
    object-fit: cover;
  }
  .card-content {
    padding: 10px;
    flex-grow: 1;
  }
  .card-title {
    margin: 0;
    font-size: 18px;
  }
  .card-sales, .card-activity {
    margin: 5px 0;
    font-size: 14px;
    color: #666;
  }

  /* 商品名称样式 */
.commodity-name {
  font-size: 14px;           /* 调整字体大小 */
  font-weight: bold;         /* 加粗字体 */
  margin: 4px 0;            /* 顶部和底部间距 */
  color: #333;               /* 文字颜色 */
  white-space: nowrap;       /* 文本不换行 */
  overflow: hidden;          /* 隐藏多余文本 */
  text-overflow: ellipsis;   /* 多余文本以省略号表示 */
  display: block;            /* 必须是 block 或 inline-block 才能使用 text-overflow */
  max-width: 100%;          /* 设置最大宽度为父元素宽度 */
}

/* 商品销量样式 */
.commodity-sales {
  font-size: 12px; /* 调整销量字体大小 */
  color: #888;
  margin-bottom: 8px; /* 底部间距 */
}

/* 特别标签样式 */
.commodity-tag {
  font-size: 12px;
  color: #fff;
  background-color: #ff6347; /* 标签背景颜色 */
  padding: 2px 4px;
  border-radius: 8px;
  text-align: center;
  width: fit-content;
}

/* 商品操作图标样式（购物车和收藏） */
.commodity-actions {
  justify-content: space-between; /* 操作图标两端对齐 */
  margin-top: auto; /* 推到卡片底部 */
  position: relative;
    right: -130px;
}

.icon-cart, .icon-favorite {
  font-size: 18px; /* 调整图标大小 */
  cursor: pointer;
  color: #ff6347; /* 图标颜色 */
  transition: color 0.2s ease-in-out; /* 图标悬停颜色变化 */
}

.icon-cart:hover {
  color: #3e8e41; /* 购物车图标悬停颜色 */
}

.icon-favorite:hover {
  color: #e74c3c; /* 收藏图标悬停颜色 */
}

div:last-child {
  color: #ff4500;
  font-size: 16px;
  font-weight: bold;
}
  </style>