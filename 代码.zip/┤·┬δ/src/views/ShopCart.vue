<template>
  <div id="app">
    <h1>{{ message }}</h1>
    <div v-if="isLoggedIn">
      <h2 class="h2-title">
      <router-link to="/shopcart" class="nav-link">购物车信息</router-link> /
      <router-link to="/paid" class="nav-link">已支付订单</router-link>
    </h2>
      <div v-for="item in cart" :key="item.id" class="card">
        <img :src="item.image" alt="商品图片" class="card-image">
        <div class="card-content">
          <h3>{{ item.name }}</h3>
          <p>价格: ¥{{ item.price }}</p>
          <p>数量：<input type="number" v-model="item.quantity" min="1" @change="updateTotalCost(item)"></p>
          <p>总花费: ¥{{ formatTotalCost(item.totalCost) }}</p>
          <button class="pay-button" @click="removeItem(item)">支付</button>
        </div>
      </div>
    </div>
    <div v-else>
      <p>请先登录</p>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      user: null,
      cart: [],
      message: '',
      isLoggedIn: false
    };
  },
  created() {
    this.checkLogin();
  },
  methods: {
    checkLogin() {
      const user = JSON.parse(localStorage.getItem('user'));
      if (user) {
        this.user = user;
        this.isLoggedIn = true;
        this.message = `欢迎回来，${user.username}！`;
        this.fetchCart(user.user_id);
      } else {
        this.message = '请先登录';
      }
    },
    async fetchCart(userId) {
      try {
        const response = await axios.get('http://localhost:3006/api/user/cart', {
          params: { userId }
        });
        this.cart = response.data.map(item => ({
          ...item,
          totalCost: this.calculateTotalCost(item.price, item.quantity)
        }));
      } catch (error) {
        console.error('获取购物车信息失败:', error);
        this.message = '获取购物车信息失败。';
      }
    },
    calculateTotalCost(price, quantity) {
      return Number(price) * Number(quantity);
    },
    updateTotalCost(item) {
      item.totalCost = this.calculateTotalCost(item.price, item.quantity);
    },
    formatTotalCost(totalCost) {
      var totalCost = Number(totalCost.toFixed(2));
      return totalCost.toFixed(2);
    },
    async removeItem(item) {
      const itemsToDelete = this.cart.filter(cartItem => cartItem.id === item.id).map(cartItem => ({
        commodityId: cartItem.id,
        quantity: cartItem.quantity
      }));

      try {
        const response = await axios.post('http://localhost:3006/api/user/paid', {
          userId: this.user.user_id,
          items: itemsToDelete
        });

        this.cart = this.cart.filter(cartItem => cartItem.id !== item.id);
        this.message = response.data.message;
      } catch (error) {
        console.error('支付请求失败:', error);
        this.message = '操作失败，请重试。';
      }
    }
  }
};
</script>

<style scoped>
.card {
  display: flex;
  border: 1px solid #ccc;
  border-radius: 8px;
  padding: 16px;
  margin: 16px 0;
  max-width: 600px;
}

.card-image {
  width: 100px;
  height: 100px;
  object-fit: cover;
  margin-right: 16px;
}
.h2-title {
  font-size: 24px;
  margin-bottom: 16px;
}

.nav-link {
  margin-right: 10px;
  color: #333;
  text-decoration: none;
}

.nav-link:hover {
  text-decoration: underline;
}

.card-content {
  flex: 1;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}

.card-content h3 {
  margin: 0;
}

.card-content p {
  margin: 8px 0;
}

.card-content input {
  width: 60px;
  padding: 4px;
  text-align: center;
}

.pay-button {
  margin-top: 10px;
  padding: 8px 12px;
  background-color: #4CAF50;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
}

.pay-button:hover {
  background-color: #45a049;
}
</style>