<template>
  <div class="home-container">
    <!-- 导航栏 -->
    <header class="navbar">
      <div class="logo">mini商城</div>
      <div class="search-user">
        <input 
          type="text" 
          placeholder="搜索商品..." 
          class="search-box" 
          @focus="navigateToSearch"
        />
        <img src="@/assets/logo.png" alt="用户头像" class="user-avatar" />
      </div>
    </header>
    <ProductList :categoryId="selectedCategoryId" />
  </div>
</template>

<script>
import CategoryList from '@/components/CategoryList.vue';
import ProductList from '@/components/ProductList.vue';

export default {
  name: 'HomeView',
  components: {
    CategoryList,
    ProductList
  },
  data() {
    return {
      selectedCategoryId: null
    };
  },
  methods: {
    selectCategory(categoryId) {
      this.selectedCategoryId = categoryId;
    },
    navigateToSearch() {
      this.$router.push({ name: 'SearchView' });
    },
  },
}
</script>

<style scoped>
.home-container {
  margin: 0 auto;
  padding: 20px 0;
  box-sizing: border-box;
}

/* 导航栏样式 */
.navbar {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 10px;
  background-color: #f8f8f8;
  position: fixed;
  width: 500px;
  z-index: 10;
}

.logo {
  font-size: 20px;
  font-weight: bold;
}

.search-user {
  display: flex;
  align-items: center;
}

.search-box {
  padding: 5px;
  margin-right: 10px;
  border: 1px solid #ccc;
  border-radius: 4px;
  width: 70%;
}

.user-avatar {
  width: 30px;
  height: 30px;
  border-radius: 50%;
}


/* 响应式布局 */
@media (max-width: 600px) {
  .home-container {
    padding: 10px;
  }

  .navbar {
    padding: 5px 10px;
  }

  .logo {
    font-size: 18px;
  }

  .search-box {
    padding: 4px;
    width: 60%;
  }

  .user-avatar {
    width: 25px;
    height: 25px;
  }

  .category-list {
    margin: 5px 0;
  }

  .product-list {
    margin: 5px 0;
  }

  .product-item {
    height: 80px;
  }

  .product-image {
    width: 60px;
    height: 60px;
  }

  .product-info {
    padding: 5px;
  }

  .product-name {
    font-size: 14px;
  }

  .product-price {
    font-size: 12px;
  }

  .add-to-cart {
    padding: 6px;
  }

  .footer-nav {
    padding: 5px 0;
  }

  .footer-link {
    font-size: 14px;
  }
}
</style>