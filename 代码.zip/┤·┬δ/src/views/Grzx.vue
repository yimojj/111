<template>
  <div class="user-center-container">
    <div v-if="isLoggedIn">
      <h2>个人中心</h2>
      <!-- 展示用户头像 -->
      <div v-if="userAvatar" class="user-avatar">
        <img :src="userAvatar" :alt="username + '的头像'">
      </div>
      <p>{{ username }}</p>
      <!-- 我的收藏 -->
      <div class="user-option" @click="goToFavorites">我的收藏</div>
      <!-- 修改信息 -->
      <div class="user-option" @click="goToEditProfile">修改信息</div>
      <!-- 如果是 admin，显示后台管理 -->
      <div v-if="username === 'admin'" class="user-option" @click="goToAdmin">后台管理</div>
      <!-- 注销按钮 -->
      <button @click="logout" class="logout-button">注销</button>
    </div>
    <div v-else>
      <p>登录查看更多内容</p>
      <button @click="goToAuth" class="ef-button">登录/注册</button>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      isLoggedIn: false, // 是否登录
      username: "", // 用户名
      userAvatar: "", // 用户头像URL
    };
  },
  methods: {
    // 检查登录状态
    checkAuthStatus() {
      const user = localStorage.getItem("user");
      const isLoggedIn = localStorage.getItem("isLoggedIn") === "true";
      
      if (isLoggedIn && user) {
        const userData = JSON.parse(user);
        this.isLoggedIn = true;
        this.username = userData.username;
        this.userAvatar = userData.avatar || "./img/logo.png"; // 从用户数据中获取头像，如果没有则为空
      } else {
        this.isLoggedIn = false;
        this.username = "";
        this.userAvatar = "";
      }
    },
    // 注销
    logout() {
      // 清除本地存储
      localStorage.removeItem("user");
      localStorage.removeItem("isLoggedIn");
      
      // 更新 Vuex 状态
      this.$store.dispatch("logout");

      // 跳转到登录页面
      this.$router.push("/auth");
    },
    // 跳转到登录/注册页面
    goToAuth() {
      this.$router.push("/auth");
    },
    // 跳转到我的收藏页面
    goToFavorites() {
      this.$router.push("/favorites");
    },
    // 跳转到修改信息页面
    goToEditProfile() {
      this.$router.push("/editprofile");
    },
    // 跳转到后台管理页面
    goToAdmin() {
      this.$router.push("/admin");
    },
  },
  created() {
    // 在组件创建时检查登录状态
    this.checkAuthStatus();
  },
};
</script>

<style scoped>
.user-center-container {
  padding: 20px;
}

.user-avatar img {
  width: 100px;
  height: 100px;
  border-radius: 50%;
  object-fit: cover;
  margin-bottom: 10px;
}

.user-option {
  margin: 10px 0;
  padding: 10px;
  background-color: #f0f0f0;
  border-radius: 5px;
  cursor: pointer;
}

.user-option:hover {
  background-color: #e0e0e0;
}

.logout-button {
  margin-top: 20px;
  padding: 10px 20px;
  background-color: #4d82ff;
  color: #fff;
  border: none;
  border-radius: 5px;
  width: 200px;
  cursor: pointer;
}

.logout-button:hover {
  background-color: #175df4;
}

.ef-button {
  padding: 10px 20px;
  background-color: #4d82ff;
  color: #fff;
  border: none;
  border-radius: 5px;
  width: 200px;
  cursor: pointer;
}

.ef-button:hover {
  background-color: #175df4;
}
</style>