/*
 Navicat Premium Data Transfer

 Source Server         : localhost
 Source Server Type    : MySQL
 Source Server Version : 80039 (8.0.39)
 Source Host           : localhost:3306
 Source Schema         : cc

 Target Server Type    : MySQL
 Target Server Version : 80039 (8.0.39)
 File Encoding         : 65001

 Date: 28/10/2024 19:10:08
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for category
-- ----------------------------
DROP TABLE IF EXISTS `category`;
CREATE TABLE `category`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 11 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of category
-- ----------------------------
INSERT INTO `category` VALUES (1, '水果');
INSERT INTO `category` VALUES (2, '蔬菜');
INSERT INTO `category` VALUES (3, '干果');
INSERT INTO `category` VALUES (4, '饮料');
INSERT INTO `category` VALUES (5, '数码');
INSERT INTO `category` VALUES (6, '电脑');
INSERT INTO `category` VALUES (7, '家居');
INSERT INTO `category` VALUES (8, '书');
INSERT INTO `category` VALUES (9, '手机');
INSERT INTO `category` VALUES (10, '礼盒');

-- ----------------------------
-- Table structure for commodity
-- ----------------------------
DROP TABLE IF EXISTS `commodity`;
CREATE TABLE `commodity`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `price` decimal(10, 2) NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `sales` int NULL DEFAULT 0,
  `special_activity_id` int NULL DEFAULT NULL,
  `category_id` int NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `special_activity_id`(`special_activity_id` ASC) USING BTREE,
  INDEX `category_id`(`category_id` ASC) USING BTREE,
  CONSTRAINT `commodity_ibfk_1` FOREIGN KEY (`special_activity_id`) REFERENCES `special_activity` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `commodity_ibfk_2` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 101 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of commodity
-- ----------------------------
INSERT INTO `commodity` VALUES (2, '苹果', 1.50, './img/sg/DM_20241027233649_002.jpg', 200, 2, 1);
INSERT INTO `commodity` VALUES (3, '橙子', 1.80, './img/sg/DM_20241027233649_003.png', 150, NULL, 1);
INSERT INTO `commodity` VALUES (4, '草莓', 3.00, './img/sg/DM_20241027233649_004.jpg', 80, 3, 1);
INSERT INTO `commodity` VALUES (5, '小米（MI）Redmi Note12 5G 手机', 1999.00, './img/sj/DM_20241027234634_002.png', 50, NULL, 9);
INSERT INTO `commodity` VALUES (6, '苹果 iPhone 14 Pro', 9999.00, './img/sj/DM_20241027234634_004.png', 25, 4, 9);
INSERT INTO `commodity` VALUES (7, '三星 Galaxy S23', 8599.00, './img/sj/DM_20241027234634_003.png', 30, NULL, 9);
INSERT INTO `commodity` VALUES (8, '华为 Mate 60 Pro', 6999.00, './img/sj/DM_20241027234634_001.png', 40, NULL, 9);
INSERT INTO `commodity` VALUES (9, '小米（MI）米家扫地机器人', 1299.00, './img/jj/DM_20241027234511_003.jpg', 60, NULL, 7);
INSERT INTO `commodity` VALUES (10, '索尼 WH-1000XM5 头戴式降噪耳机', 2999.00, './img/sm/DM_20241027234345_003.png', 20, NULL, 5);
INSERT INTO `commodity` VALUES (11, '适马 16mm f/1.4 DC 林业镜头', 3000.00, './img/sm/DM_20241027234345_004.jpg', 15, NULL, 5);
INSERT INTO `commodity` VALUES (12, '戴尔 XPS 13 笔记本电脑', 9999.00, './img/dn/DM_20241027234431_001.jpg', 10, 2, 6);
INSERT INTO `commodity` VALUES (13, '联想 ThinkPad X1 Carbon', 10999.00, './img/dn/DM_20241027234431_004.jpg', 12, NULL, 6);
INSERT INTO `commodity` VALUES (14, '微软 Surface Pro 9', 8688.00, './img/dn/DM_20241027234431_005.jpg', 18, NULL, 6);
INSERT INTO `commodity` VALUES (15, 'HP 惠普 Envy 14 笔记本', 7499.00, './img/dn/DM_20241027234431_002.png', 22, 3, 6);
INSERT INTO `commodity` VALUES (16, '苹果 MacBook Air M2', 9499.00, './img/dn/DM_20241027234431_003.jpg', 11, NULL, 6);
INSERT INTO `commodity` VALUES (17, '乐高 75290 帝国飞船', 699.00, './img/s/DM_20241027234551_002.jpg', 100, 4, 8);
INSERT INTO `commodity` VALUES (18, '《三体》- 刘慈欣', 89.00, './img/s/DM_20241027234551_001.jpg', 300, NULL, 8);
INSERT INTO `commodity` VALUES (19, '《战争与和平》- 列夫·托尔斯泰', 129.00, './img/s/DM_20241027234551_005.jpg', 200, 4, 8);
INSERT INTO `commodity` VALUES (20, '《百年孤独》- 加西亚·马尔克斯', 79.00, './img/s/DM_20241027234551_004.jpg', 250, NULL, 8);
INSERT INTO `commodity` VALUES (21, '厄瓜多尔香蕉', 1.50, './img/sc/DM_20241027234049_007.jpg', 150, 3, 2);
INSERT INTO `commodity` VALUES (22, '新西兰奇异果', 3.00, './img/sg/DM_20241027233649_007.jpg', 120, NULL, 1);
INSERT INTO `commodity` VALUES (23, '青浦青菜', 2.00, './img/sc/DM_20241027234049_007.jpg', 200, 5, 2);
INSERT INTO `commodity` VALUES (24, '红心火龙果', 10.00, './img/sg/DM_20241027233649_007.jpg', 100, 3, 1);
INSERT INTO `commodity` VALUES (25, '草莓', 5.00, './img/sg/DM_20241027233649_006.jpg', 80, NULL, 1);
INSERT INTO `commodity` VALUES (26, '大米（五常稻花香）', 100.00, './img/sc/DM_20241027234049_001.png', 90, 2, 2);
INSERT INTO `commodity` VALUES (27, '湖北特产礼盒', 499.00, './img/lh/DM_20241027234712_004.jpg', 60, 1, 10);
INSERT INTO `commodity` VALUES (28, '黄桥烧饼', 25.00, './img/sc/DM_20241027234049_003.jpg', 150, 4, 2);
INSERT INTO `commodity` VALUES (29, '百福干果礼包', 299.00, './img/gg/DM_20241027234139_002.jpg', 70, NULL, 3);
INSERT INTO `commodity` VALUES (30, '龙井茶', 180.00, './img/yl/DM_20241027234245_001.jpg', 200, 5, 4);
INSERT INTO `commodity` VALUES (31, '每逢佳节倍思亲礼品盒', 375.00, './img/lh/DM_20241027234712_001.jpg', 180, 4, 10);
INSERT INTO `commodity` VALUES (32, '榴莲', 40.00, './img/sg/DM_20241027233649_007.jpg', 110, NULL, 1);
INSERT INTO `commodity` VALUES (33, '新疆干果大礼包', 399.00, './img/gg/DM_20241027234139_001.jpg', 50, 5, 3);
INSERT INTO `commodity` VALUES (34, '浓香咖啡豆', 250.00, './img/yl/DM_20241027234245_001.jpg', 120, 4, 4);
INSERT INTO `commodity` VALUES (35, '云南普洱茶', 220.00, './img/yl/DM_20241027234245_001.jpg', 130, 3, 4);
INSERT INTO `commodity` VALUES (36, '自制酸奶', 15.00, './img/yl/DM_20241027234245_001.jpg', 200, NULL, 4);
INSERT INTO `commodity` VALUES (37, '鱼香肉丝调料包', 10.00, './img/yl/DM_20241027234245_001.jpg', 220, NULL, 4);
INSERT INTO `commodity` VALUES (38, '手工米线', 25.00, './img/sc/DM_20241027234049_007.jpg', 150, 1, 2);
INSERT INTO `commodity` VALUES (39, '盐焗鸡', 22.00, './img/sc/DM_20241027234049_007.jpg', 90, 2, 2);
INSERT INTO `commodity` VALUES (40, '无糖植物饮料', 12.00, './img/yl/DM_20241027234245_003.jpg', 250, NULL, 4);
INSERT INTO `commodity` VALUES (41, '酱香肉松', 10.00, './img/yl/DM_20241027234245_001.jpg', 180, NULL, 4);
INSERT INTO `commodity` VALUES (42, '米酒', 40.00, './img/yl/DM_20241027234245_001.jpg', 40, NULL, 4);
INSERT INTO `commodity` VALUES (43, '健康无糖坚果', 35.00, './img/gg/DM_20241027234139_003.jpg', 150, 4, 3);
INSERT INTO `commodity` VALUES (44, '新鲜菠菜', 5.00, './img/sc/DM_20241027234049_007.jpg', 200, NULL, 2);
INSERT INTO `commodity` VALUES (45, '豆腐干', 10.00, './img/sc/DM_20241027234049_007.jpg', 100, NULL, 2);
INSERT INTO `commodity` VALUES (46, '甜玉米', 4.00, './img/sc/DM_20241027234049_002.jpg', 120, 5, 2);
INSERT INTO `commodity` VALUES (47, '皮蛋', 6.00, './img/sc/DM_20241027234049_004.jpg', 80, NULL, 2);
INSERT INTO `commodity` VALUES (48, '红薯', 3.00, './img/sc/DM_20241027234049_005.png', 160, 3, 2);
INSERT INTO `commodity` VALUES (49, '土豆', 2.00, './img/sc/DM_20241027234049_006.jpg', 140, NULL, 2);
INSERT INTO `commodity` VALUES (50, '西红柿', 3.50, './img/sc/DM_20241027234049_007.jpg', 130, 1, 2);
INSERT INTO `commodity` VALUES (51, '山药', 15.00, './img/sc/DM_20241027234049_007.jpg', 90, NULL, 2);
INSERT INTO `commodity` VALUES (52, '菠菜粉', 20.00, './img/sc/DM_20241027234049_007.jpg', 60, NULL, 2);
INSERT INTO `commodity` VALUES (53, '新鲜草莓', 6.00, './img/sg/DM_20241027233649_007.jpg', 100, 2, 1);
INSERT INTO `commodity` VALUES (54, '甜橙', 8.00, './img/sg/DM_20241027233649_005.jpg', 110, NULL, 1);
INSERT INTO `commodity` VALUES (55, '孕妇奶粉', 300.00, './img/yl/DM_20241027234245_001.jpg', 50, NULL, 4);
INSERT INTO `commodity` VALUES (56, '儿童牛奶', 150.00, './img/yl/DM_20241027234245_005.jpg', 80, 4, 4);
INSERT INTO `commodity` VALUES (57, '婴儿米粉', 25.00, './img/yl/DM_20241027234245_006.jpg', 200, NULL, 4);
INSERT INTO `commodity` VALUES (58, '功能性饮料', 15.00, './img/yl/DM_20241027234245_006.jpg', 90, 3, 4);
INSERT INTO `commodity` VALUES (59, '小米你家送温暖大礼包', 500.00, './img/lh/DM_20241027234712_003.jpg', 40, NULL, 10);
INSERT INTO `commodity` VALUES (60, '创意家居饰品', 199.00, './img/jj/DM_20241027234511_001.jpg', 110, NULL, 7);
INSERT INTO `commodity` VALUES (61, '智能家居控制器', 799.00, './img/jj/DM_20241027234511_001.jpg', 80, 4, 7);
INSERT INTO `commodity` VALUES (62, '家有小管家', 299.00, './img/jj/DM_20241027234511_001.jpg', 70, NULL, 7);
INSERT INTO `commodity` VALUES (63, '餐具套装', 150.00, './img/jj/DM_20241027234511_001.jpg', 120, NULL, 7);
INSERT INTO `commodity` VALUES (64, '抗菌洗手液', 35.00, './img/yl/DM_20241027234245_004.jpg', 150, NULL, 4);
INSERT INTO `commodity` VALUES (65, '厨具五件套', 499.00, './img/jj/DM_20241027234511_001.jpg', 60, NULL, 7);
INSERT INTO `commodity` VALUES (66, '洗碗机', 3500.00, './img/jj/DM_20241027234511_001.jpg', 10, NULL, 7);
INSERT INTO `commodity` VALUES (67, '无线吸尘器', 899.00, './img/jj/DM_20241027234511_001.jpg', 20, NULL, 7);
INSERT INTO `commodity` VALUES (68, '微波炉', 1999.00, './img/jj/DM_20241027234511_001.jpg', 30, NULL, 7);
INSERT INTO `commodity` VALUES (69, '插线板', 59.00, './img/sm/DM_20241027234345_004.jpg', 100, NULL, 5);
INSERT INTO `commodity` VALUES (70, 'LED台灯', 199.00, './img/jj/DM_20241027234511_001.jpg', 110, NULL, 7);
INSERT INTO `commodity` VALUES (71, '智能插座', 99.00, './img/jj/DM_20241027234511_001.jpg', 150, NULL, 7);
INSERT INTO `commodity` VALUES (72, '无线蓝牙音箱', 399.00, './img/sm/DM_20241027234345_004.jpg', 90, NULL, 5);
INSERT INTO `commodity` VALUES (73, '外接硬盘', 499.00, './img/sm/DM_20241027234345_005.png', 60, NULL, 5);
INSERT INTO `commodity` VALUES (74, 'USB风扇', 29.00, './img/sm/DM_20241027234345_004.jpg', 200, NULL, 5);
INSERT INTO `commodity` VALUES (75, '高清监控摄像头', 799.00, './img/sm/DM_20241027234345_006.jpg', 30, NULL, 5);
INSERT INTO `commodity` VALUES (76, '机箱散热风扇', 99.00, './img/sm/DM_20241027234345_004.jpg', 80, NULL, 5);
INSERT INTO `commodity` VALUES (77, '智能手环', 149.00, './img/sm/DM_20241027234345_006.jpg', 120, NULL, 5);
INSERT INTO `commodity` VALUES (78, '运动耳机', 399.00, './img/sm/DM_20241027234345_006.jpg', 90, NULL, 5);
INSERT INTO `commodity` VALUES (79, '智能门锁', 1399.00, './img/sm/DM_20241027234345_002.jpg', 50, NULL, 5);
INSERT INTO `commodity` VALUES (80, '电子书阅读器', 899.00, './img/s/DM_20241027234551_003.jpg', 60, NULL, 8);
INSERT INTO `commodity` VALUES (81, '按摩椅', 2999.00, './img/jj/DM_20241027234511_002.jpg', 20, NULL, 7);
INSERT INTO `commodity` VALUES (82, '电动牙刷', 499.00, './img/yl/DM_20241027234245_002.jpg', 40, NULL, 4);
INSERT INTO `commodity` VALUES (83, '智能电视', 3999.00, './img/sm/DM_20241027234345_001.png', 25, NULL, 5);
INSERT INTO `commodity` VALUES (84, '洗衣机', 2499.00, './img/jj/DM_20241027234511_001.jpg', 15, NULL, 7);
INSERT INTO `commodity` VALUES (85, '烤箱', 899.00, './img/jj/DM_20241027234511_004.jpg', 35, NULL, 7);
INSERT INTO `commodity` VALUES (86, '空气净化器', 999.00, './img/jj/DM_20241027234511_005.jpg', 20, NULL, 7);
INSERT INTO `commodity` VALUES (87, '电饭煲', 399.00, './img/jj/DM_20241027234511_006.jpg', 50, NULL, 7);
INSERT INTO `commodity` VALUES (88, '多功能料理机', 699.00, './img/jj/DM_20241027234511_001.jpg', 45, NULL, 7);
INSERT INTO `commodity` VALUES (89, '便携式榨汁机', 299.00, './img/yl/DM_20241027234245_001.jpg', 30, NULL, 4);
INSERT INTO `commodity` VALUES (90, '早餐机', 499.00, './img/yl/DM_20241027234245_001.jpg', 25, NULL, 4);
INSERT INTO `commodity` VALUES (91, '瞬间冷水饮料机', 499.00, './img/yl/DM_20241027234245_001.jpg', 15, NULL, 4);
INSERT INTO `commodity` VALUES (92, '蛋糕机', 699.00, './img/yl/DM_20241027234245_001.jpg', 10, NULL, 4);
INSERT INTO `commodity` VALUES (93, '葱油饼', 20.00, './img/sc/DM_20241027234049_007.jpg', 200, NULL, 2);
INSERT INTO `commodity` VALUES (94, '豆乳机', 399.00, './img/yl/DM_20241027234245_001.jpg', 50, NULL, 4);
INSERT INTO `commodity` VALUES (95, '五谷杂粮礼盒', 299.00, './img/lh/DM_20241027234712_002.jpg', 80, NULL, 10);
INSERT INTO `commodity` VALUES (96, '纯牛奶', 15.00, './img/yl/DM_20241027234245_001.jpg', 100, NULL, 4);
INSERT INTO `commodity` VALUES (97, '奶酪', 30.00, './img/yl/DM_20241027234245_001.jpg', 90, NULL, 4);
INSERT INTO `commodity` VALUES (98, '薄饼', 20.00, './img/sc/DM_20241027234049_007.jpg', 150, NULL, 2);
INSERT INTO `commodity` VALUES (99, '黑米', 10.00, './img/sc/DM_20241027234049_007.jpg', 130, NULL, 2);
INSERT INTO `commodity` VALUES (100, '荔枝', 6.00, './img/sg/DM_20241027233649_007.jpg', 200, NULL, 1);

-- ----------------------------
-- Table structure for special_activity
-- ----------------------------
DROP TABLE IF EXISTS `special_activity`;
CREATE TABLE `special_activity`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `activity_name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of special_activity
-- ----------------------------
INSERT INTO `special_activity` VALUES (1, '百亿补贴');
INSERT INTO `special_activity` VALUES (2, '限时折扣');
INSERT INTO `special_activity` VALUES (3, '积分翻倍');
INSERT INTO `special_activity` VALUES (4, '9.9折');
INSERT INTO `special_activity` VALUES (5, '6.6折');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `favorites` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `avatar` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `cart` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `paid` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  PRIMARY KEY (`user_id`) USING BTREE,
  UNIQUE INDEX `username`(`username` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 24 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (1, 'user1', 'password1', '[3,4]', NULL, '[{\"commodityId\":3,\"quantity\":2},{\"commodityId\":2,\"quantity\":1}]', '[{\"commodityId\":1,\"quantity\":4}]');
INSERT INTO `users` VALUES (2, 'user2', 'password2', '[1,2]', NULL, '[12]', '[]');
INSERT INTO `users` VALUES (3, 'user3', 'password3', '[]', NULL, '[]', '[]');
INSERT INTO `users` VALUES (4, 'user4', 'password4', '[]', NULL, '[]', '[]');
INSERT INTO `users` VALUES (5, 'user5', 'password5', '[]', NULL, '[]', '[]');
INSERT INTO `users` VALUES (17, 'admin', '123', '[2]', '', '[{\"commodityId\":2,\"quantity\":1}]', '[{\"commodityId\":2,\"quantity\":1}]');
INSERT INTO `users` VALUES (18, '1234', '1234', '[]', '', '[]', '[]');
INSERT INTO `users` VALUES (19, '123345', '123', '[]', '', '[]', '[]');
INSERT INTO `users` VALUES (23, '1111', '111', '[8,1]', '', '[{\"commodityId\":1,\"quantity\":1}]', '[{\"commodityId\":1,\"quantity\":6},{\"commodityId\":2,\"quantity\":3}]');

SET FOREIGN_KEY_CHECKS = 1;
