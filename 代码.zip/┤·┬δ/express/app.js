const express = require('express');
const mysql = require('mysql2/promise');
const cors = require('cors');
const categoriesController = require('./controllers/categories');
const commoditiesController = require('./controllers/commodities');
const usersController = require('./controllers/user');

const app = express();
const port = 3006;

// 添加 CORS 支持
app.use(cors());
app.use(express.json());

// 创建数据库连接池
const pool = mysql.createPool({
  host: 'localhost',
  user: 'root',
  password: '123456',
  database: 'cc',
  connectionLimit: 10,
});

// 获取 `category` 数据
app.get('/api/categories', categoriesController.getCategories);

// 获取所有 commodity 数据
app.get('/api/commodities/all', commoditiesController.getAllCommodities);

// 删除商品信息
app.delete('/api/commodities/:commodityId', commoditiesController.deleteCommodity);

// 修改商品信息
app.put('/api/commodities/:commodityId', commoditiesController.updateCommodity);

// 查询 commodity 数据
app.get('/api/commodities', commoditiesController.getCommodities);

// 获取所有用户信息
app.get('/api/user', usersController.getAllUsers);

//根据用户id获取用户信息
app.get('/api/users/:userId', usersController.getUserById);

// 删除用户信息
app.delete('/api/user/:userId', usersController.deleteUser);

// 用户注册
app.post('/api/register', usersController.registerUser);

// 用户登录
app.post('/api/login',  usersController.loginUser);

// 修改用户信息
app.put('/api/user/:userId',  usersController.updateUser);

// 获取用户收藏的商品
app.get('/api/user/favorites',  usersController.getUserFavorites);

// 用户加入收藏商品
app.post('/api/user/favorite',  usersController.addUserFavorites);

// 用户取消收藏商品
app.post('/api/user/unfavorite',  usersController.removeUserFavorites);

// 获取用户购物车的商品
app.get('/api/user/cart',   usersController.getUserCart);

// 获取用户已支付的商品
app.get('/api/user/paid',  usersController.getUserPaid);

// 添加商品到购物车
app.post('/api/user/add-to-cart', usersController.addToCart);

// 删除购物车中的商品并更新支付信息
app.post('/api/user/paid',  usersController.deleteFromCart);

// 启动服务器
app.listen(port, () => {
  console.log(`服务器正在运行在 http://localhost:${port}`);
});