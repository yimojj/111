const pool = require('../db'); // 引入数据库连接池

module.exports = {
  // 获取 `category` 数据
  getCategories: async (req, res) => {
    try {
      const [rows] = await pool.query('SELECT * FROM category');
      res.json(rows);
    } catch (err) {
      res.status(500).json({ message: '数据库查询错误', error: err });
    }
  },
};