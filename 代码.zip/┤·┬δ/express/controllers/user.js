const pool = require('../db'); // 引入数据库连接池
const mysql = require('mysql2/promise');

module.exports = {
  // 获取所有 users 数据
  getAllUsers: async (req, res) => {
    try {
      const [rows] = await pool.query('SELECT * FROM users');
      res.status(200).json({ users: rows });
    } catch (err) {
      console.error('Database error:', err);
      res.status(500).json({ message: '数据库查询错误', error: err.message });
    }
  },
  // 根据用户ID获取用户信息
  getUserById: async (req, res) => {
    const userId = req.params.userId;
  
    try {
      const [rows] = await pool.query('SELECT * FROM users WHERE user_id = ?', [userId]);
  
      if (rows.length === 0) {
        return res.status(404).json({ message: '用户不存在' });
      }
    }
    catch (err) {
      console.error('Database error:', err);
      res.status(500).json({ message: '数据库查询错误', error: err.message });
    }
  },

  // 根据用户ID删除用户信息
  deleteUser: async (req, res) => {
    const userId = req.params.userId;
  
    try {
      // 删除用户信息
      const [result] = await pool.query('DELETE FROM users WHERE user_id = ?', [userId]);
  
      if (result.affectedRows === 0) {
        return res.status(404).json({ message: '用户不存在' });
      }
  
      // 返回删除成功的消息
      res.status(200).json({ message: '用户删除成功' });
    } catch (err) {
      // 捕获并返回详细的错误信息
      console.error('Database error:', err);
      res.status(500).json({ message: '数据库操作错误', error: err.message });
    }
  },

  //注册用户    
  registerUser: async (req, res) => {
    const { username, password, favorites, avatar, cart, paid } = req.body;
  
    // 验证必填项
    if (!username || !password) {
      return res.status(400).json({ message: '用户名和密码是必填项' });
    }
  
    try {
      // 检查用户名是否已存在
      const [rows] = await pool.query('SELECT * FROM users WHERE username = ?', [username]);
      if (rows.length > 0) {
        return res.status(409).json({ message: '用户名已存在' });
      }
  
      // 调试：打印要插入的数据
      console.log('Inserting data:', {
        username,
        password,
        favorites: JSON.stringify(favorites) || '[]',
        avatar: avatar || '',
        cart: JSON.stringify(cart) || '[]',
        paid: JSON.stringify(paid) || '[]'
      });
  
      // 插入新用户
      const [result] = await pool.query(
        'INSERT INTO users (username, password, favorites, avatar, cart, paid) VALUES (?, ?, ?, ?, ?, ?)',
        [
          username,
          password,
          JSON.stringify(favorites) || '[]',
          avatar || '',
          JSON.stringify(cart) || '[]',
          JSON.stringify(paid) || '[]'
        ]
      );
  
      console.log('Insert result:', result); // 打印插入结果
  
      // 查询刚刚插入的用户信息
      const [userRows] = await pool.query('SELECT * FROM users WHERE user_id = ?', [result.insertId]);
      if (userRows.length === 0) {
        return res.status(500).json({ message: '用户信息获取失败' });
      }
  
      const user = userRows[0];
  
      // 返回用户信息
      res.status(201).json({
        message: '用户注册成功',
        user: {
          user_id: user.user_id,
          username: user.username,
          password: user.password,
          favorites: JSON.parse(user.favorites),
          avatar: user.avatar,
          cart: JSON.parse(user.cart),
          paid: JSON.parse(user.paid)
        }
      });
    } catch (err) {
      // 捕获并返回详细的错误信息
      let errorMessage;
      if (err.code === 'ER_DUP_ENTRY') {
        errorMessage = '用户名已存在';
      } else if (err.code === 'ER_BAD_NULL_ERROR') {
        errorMessage = '缺少必填字段';
      } else if (err.code === 'ER_TRUNCATED_WRONG_VALUE') {
        errorMessage = '字段值格式错误';
      } else {
        errorMessage = '数据库查询错误';
      }
      console.error('Database error:', err); // 打印完整的错误信息
      res.status(500).json({ message: errorMessage, error: err.message });
    }
  },

  //用户登录
  loginUser: async (req, res) => {
    const { username, password } = req.body;
  
    if (!username || !password) {
      return res.status(400).json({ message: '用户名和密码是必填项' });
    }
  
    try {
      const [rows] = await pool.query('SELECT * FROM users WHERE username = ?', [username]);
      if (rows.length === 0 || rows[0].password !== password) {
        return res.status(401).json({ message: '用户名或密码错误' });
      }
  
      res.status(200).json({ message: '登录成功', user: rows[0] });
    } catch (err) {
      res.status(500).json({ message: '数据库查询错误', error: err });
    }
  },

  //修改用户信息
  updateUser:  async (req, res) => {
    const userId = req.params.userId;
    const { username, password } = req.body;
  
    // 验证必填项
    if (!username && !password) {
      return res.status(400).json({ message: '用户名和密码至少有一项是必填项' });
    }
  
    try {
      // 检查新用户名是否已存在（如果提供了新用户名）
      if (username) {
        const [rows] = await pool.query('SELECT * FROM users WHERE username = ? AND user_id != ?', [username, userId]);
        if (rows.length > 0) {
          return res.status(409).json({ message: '用户名已存在' });
        }
      }
  
      // 调试：打印要更新的数据
      console.log('Updating data:', {
        userId,
        username,
        password
      });
  
      // 构造更新语句
      let updateFields = [];
      let updateValues = [];
  
      if (username) {
        updateFields.push('username = ?');
        updateValues.push(username);
      }
  
      if (password) {
        updateFields.push('password = ?');
        updateValues.push(password);
      }
  
      updateValues.push(userId);
  
      const updateQuery = `UPDATE users SET ${updateFields.join(', ')} WHERE user_id = ?`;
  
      // 更新用户信息
      const [result] = await pool.query(updateQuery, updateValues);
  
      console.log('Update result:', result); // 打印更新结果
  
      if (result.affectedRows === 0) {
        return res.status(404).json({ message: '用户不存在' });
      }
  
      // 查询更新后的用户信息
      const [userRows] = await pool.query('SELECT * FROM users WHERE user_id = ?', [userId]);
      if (userRows.length === 0) {
        return res.status(500).json({ message: '用户信息获取失败' });
      }
  
      const user = userRows[0];
  
      // 返回更新后的用户信息
      res.status(200).json({
        message: '用户信息更新成功',
        user: {
          id: user.user_id,
          username: user.username,
          favorites: JSON.parse(user.favorites),
          avatar: user.avatar,
          cart: JSON.parse(user.cart),
          paid: JSON.parse(user.paid)
        }
      });
    } catch (err) {
      // 捕获并返回详细的错误信息
      let errorMessage;
      if (err.code === 'ER_DUP_ENTRY') {
        errorMessage = '用户名已存在';
      } else if (err.code === 'ER_BAD_NULL_ERROR') {
        errorMessage = '缺少必填字段';
      } else if (err.code === 'ER_TRUNCATED_WRONG_VALUE') {
        errorMessage = '字段值格式错误';
      } else {
        errorMessage = '数据库查询错误';
      }
      console.error('Database error:', err); // 打印完整的错误信息
      res.status(500).json({ message: errorMessage, error: err.message });
    }
  },

  // 获取用户收藏的商品
  getUserFavorites: async (req, res) => {
    const { userId } = req.query;
  
    if (!userId) {
      return res.status(400).json({ message: '用户ID是必填项' });
    }
  
    try {
      // 获取用户的收藏商品编号
      const [userRows] = await pool.query('SELECT favorites FROM users WHERE user_id = ?', [userId]);
      if (userRows.length === 0) {
        return res.status(404).json({ message: '用户不存在' });
      }
  
      // favorites 现在是一个 JSON 对象
      const favorites = userRows[0].favorites ? JSON.parse(userRows[0].favorites) : [];
  
      // 通过检查 favorites 进行下一步操作
      if (favorites.length === 0) {
        return res.json([]);
      }
  
      // 查询商品信息
      const sql = `
        SELECT c.*, sa.activity_name AS special_activity_name 
        FROM commodity c
        LEFT JOIN special_activity sa ON c.special_activity_id = sa.id
        WHERE c.id IN (?)
      `;
  
      const [commodityRows] = await pool.execute(mysql.format(sql, [favorites]));
      res.json(commodityRows);
    } catch (err) {
      console.error("数据库查询错误:", err);
      res.status(500).json({ message: '数据库查询错误', error: err.message });
    }
  },

// 用户加入收藏商品
  addUserFavorites:async (req, res) => {
    const { userId, commodityId } = req.body;
  
    if (!userId || !commodityId) {
      return res.status(400).json({ message: '用户ID和商品ID是必填项' });
    }
  
    try {
      // 获取用户的收藏商品编号
      const [userRows] = await pool.query('SELECT favorites FROM users WHERE user_id = ?', [userId]);
      if (userRows.length === 0) {
        return res.status(404).json({ message: '用户不存在' });
      }
  
      // 解析现有的收藏列表（确保它是一个数组，即使为空）
      let favorites = userRows[0].favorites ? JSON.parse(userRows[0].favorites) : [];
  
      // 检查商品是否已经在收藏列表中
      if (favorites.includes(commodityId)) {
        return res.status(400).json({ message: '商品已在收藏列表中' });
      }
  
      // 将商品添加到收藏列表中
      favorites.push(commodityId);
  
      // 将更新后的收藏列表转换回 JSON 字符串
      const favoritesJson = JSON.stringify(favorites);
  
      // 更新用户的收藏列表
      await pool.query('UPDATE users SET favorites = ? WHERE user_id = ?', [favoritesJson, userId]);
  
      // 返回成功响应
      res.json({ message: '加入收藏成功' });
    } catch (err) {
      console.error("数据库查询错误:", err);
      res.status(500).json({ message: '数据库查询错误', error: err.message });
    }
  },

// 用户取消收藏商品
  removeUserFavorites:async (req, res) => {
    const { userId, commodityId } = req.body;
  
    if (!userId || !commodityId) {
      return res.status(400).json({ message: '用户ID和商品ID是必填项' });
    }
  
    try {
      // 获取用户的收藏商品编号
      const [userRows] = await pool.query('SELECT favorites FROM users WHERE user_id = ?', [userId]);
      if (userRows.length === 0) {
        return res.status(404).json({ message: '用户不存在' });
      }
  
      // 解析现有的收藏列表（确保它是一个数组，即使为空）
      let favorites = userRows[0].favorites ? JSON.parse(userRows[0].favorites) : [];
  
      // 检查商品是否在收藏列表中
      const index = favorites.indexOf(commodityId);
      if (index === -1) {
        return res.status(400).json({ message: '商品不在收藏列表中' });
      }
  
      // 从收藏列表中移除商品
      favorites.splice(index, 1);
  
      // 将更新后的收藏列表转换回 JSON 字符串
      const favoritesJson = JSON.stringify(favorites);
  
      // 更新用户的收藏列表
      await pool.query('UPDATE users SET favorites = ? WHERE user_id = ?', [favoritesJson, userId]);
  
      // 返回成功响应
      res.json({ message: '取消收藏成功' });
    } catch (err) {
      console.error("数据库查询错误:", err);
      res.status(500).json({ message: '数据库查询错误', error: err.message });
    }
  },

  // 获取用户购物车的商品
  getUserCart:async (req, res) => {
    const { userId } = req.query;
  
    // 检查用户ID是否在URL中正确传递
    if (!userId) {
      return res.status(400).json({ message: '用户ID是必填项' });
    }
  
    try {
      // 查询用户是否存在，并获取其购物车信息
      const [userRows] = await pool.query('SELECT cart FROM users WHERE user_id = ?', [userId]);
      
      // 如果用户不存在，返回404
      if (userRows.length === 0) {
        return res.status(404).json({ message: '用户不存在，请检查用户ID是否正确' });
      }
  
      // 解析用户的购物车信息
      const cart = userRows[0].cart ? JSON.parse(userRows[0].cart) : [];
  
      // 如果购物车为空，直接返回空数组
      if (cart.length === 0) {
        return res.json([]);
      }
  
      // 提取商品 ID 列表
      const commodityIds = cart.map(item => item.commodityId);
  
      // 查询商品信息
      const sql = `
        SELECT c.*, sa.activity_name AS special_activity_name 
        FROM commodity c
        LEFT JOIN special_activity sa ON c.special_activity_id = sa.id
        WHERE c.id IN (?)
      `;
  
      // 执行查询
      const [commodityRows] = await pool.execute(mysql.format(sql, [commodityIds]));
      
      // 如果未查到任何商品信息
      if (commodityRows.length === 0) {
        return res.status(404).json({ message: '未找到任何商品信息' });
      }
  
      // 为商品信息添加数量
      const cartWithDetails = commodityRows.map(commodity => {
        const cartItem = cart.find(item => item.commodityId === commodity.id);
        return {
          ...commodity,
          quantity: cartItem.quantity, // 添加数量
        };
      });
  
      // 返回带有数量的商品详细信息
      res.json(cartWithDetails);
    } catch (err) {
      console.error("数据库查询错误:", err);
      res.status(500).json({ message: '数据库查询错误', error: err.message });
    }
  },

  // 获取用户已支付的商品
  getUserPaid:async (req, res) => {
    const { userId } = req.query;
  
    // 检查用户ID是否在URL中正确传递
    if (!userId) {
      return res.status(400).json({ message: '用户ID是必填项' });
    }
  
    try {
      // 查询用户是否存在，并获取其已支付的订单信息
      const [userRows] = await pool.query('SELECT paid FROM users WHERE user_id = ?', [userId]);
      
      // 如果用户不存在，返回404
      if (userRows.length === 0) {
        return res.status(404).json({ message: '用户不存在，请检查用户ID是否正确' });
      }
  
      // 解析用户的已支付订单信息
      const paidItems = userRows[0].paid ? JSON.parse(userRows[0].paid) : [];
  
      // 如果已支付订单为空，直接返回空数组
      if (paidItems.length === 0) {
        return res.json([]);
      }
  
      // 提取商品 ID 列表
      const commodityIds = paidItems.map(item => item.commodityId);
  
      // 查询商品信息
      const sql = `
        SELECT c.*, sa.activity_name AS special_activity_name 
        FROM commodity c
        LEFT JOIN special_activity sa ON c.special_activity_id = sa.id
        WHERE c.id IN (?)
      `;
  
      // 执行查询
      const [commodityRows] = await pool.execute(mysql.format(sql, [commodityIds]));
      
      // 如果未查到任何商品信息
      if (commodityRows.length === 0) {
        return res.status(404).json({ message: '未找到任何商品信息' });
      }
  
      // 为商品信息添加数量
      const paidItemsWithDetails = commodityRows.map(commodity => {
        const paidItem = paidItems.find(item => item.commodityId === commodity.id);
        return {
          ...commodity,
          quantity: paidItem.quantity, // 添加数量
        };
      });
  
      // 返回带有数量的商品详细信息
      res.json(paidItemsWithDetails);
    } catch (err) {
      console.error("数据库查询错误:", err);
      res.status(500).json({ message: '数据库查询错误', error: err.message });
    }
  },

  // 添加商品到购物车
  addToCart:  async (req, res) => {
    const { userId, commodityId, quantity } = req.body;
  
    if (!userId || !commodityId || quantity === undefined) {
      return res.status(400).json({ message: '用户ID、商品ID和数量是必填项' });
    }
  
    try {
      const [userRows] = await pool.query('SELECT cart FROM users WHERE user_id = ?', [userId]);
      if (userRows.length === 0) {
        return res.status(404).json({ message: '用户不存在' });
      }
  
      let cart = userRows[0].cart ? JSON.parse(userRows[0].cart) : [];
      const existingItem = cart.find(item => item.commodityId === commodityId);
      if (existingItem) {
        existingItem.quantity += quantity;
      } else {
        cart.push({ commodityId, quantity }); // 存储商品ID和数量
      }
  
      await pool.query('UPDATE users SET cart = ? WHERE user_id = ?', [JSON.stringify(cart), userId]);
  
      res.json({ message: '商品已成功加入购物车' });
    } catch (err) {
      console.error('Error in /api/user/add-to-cart:', err);
      res.status(500).json({ message: '数据库查询错误', error: err.message });
    }
  },

  // 删除购物车中的商品并更新支付信息
  deleteFromCart:  async (req, res) => {
    const { userId, items } = req.body;
  
    if (!userId || !items || !Array.isArray(items)) {
      return res.status(400).json({ message: '用户ID和商品列表是必填项' });
    }
  
    try {
      const [userRows] = await pool.query('SELECT cart, paid FROM users WHERE user_id = ?', [userId]);
      if (userRows.length === 0) {
        return res.status(404).json({ message: '用户不存在' });
      }
  
      let cart = userRows[0].cart ? JSON.parse(userRows[0].cart) : [];
      let paid = userRows[0].paid ? JSON.parse(userRows[0].paid) : [];
  
      items.forEach(item => {
        const { commodityId, quantity } = item;
        const existingItem = paid.find(paidItem => paidItem.commodityId === commodityId);
        if (existingItem) {
          existingItem.quantity += quantity;
        } else {
          paid.push({ commodityId, quantity });
        }
      });
  
      cart = cart.filter(cartItem => !items.some(item => item.commodityId === cartItem.commodityId));
  
      await pool.query('UPDATE users SET cart = ?, paid = ? WHERE user_id = ?', [JSON.stringify(cart), JSON.stringify(paid), userId]);
  
      res.json({ message: '已支付成功' });
    } catch (err) {
      console.error('Error in /api/user/paid:', err);
      res.status(500).json({ message: '数据库查询错误', error: err.message });
    }
  },

};