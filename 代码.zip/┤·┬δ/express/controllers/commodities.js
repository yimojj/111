const pool = require('../db'); // 引入数据库连接池

module.exports = {
  // 获取所有 commodity 数据
  getAllCommodities: async (req, res) => {
    {
        try {
          const query = `
            SELECT c.*, sa.activity_name AS special_activity_name 
            FROM commodity c
            LEFT JOIN special_activity sa ON c.special_activity_id = sa.id
          `;
      
          console.log('SQL Query:', query);
          const [rows] = await pool.query(query);
          res.status(200).json({ commodities: rows });
        } catch (err) {
          console.error('Database error:', err);
          res.status(500).json({ message: '数据库查询错误', error: err.message });
        }
      }
  },

  // 删除商品信息
  deleteCommodity: async (req, res) => {
    const commodityId = req.params.commodityId;
  
    try {
      // 删除商品信息
      const [result] = await pool.query('DELETE FROM commodity WHERE id = ?', [commodityId]);
  
      if (result.affectedRows === 0) {
        return res.status(404).json({ message: '商品不存在' });
      }
  
      // 返回删除成功的消息
      res.status(200).json({ message: '商品删除成功' });
    } catch (err) {
      // 捕获并返回详细的错误信息
      console.error('Database error:', err);
      res.status(500).json({ message: '数据库操作错误', error: err.message });
    }
  },

  // 修改商品信息
  updateCommodity: async (req, res) => {
    const commodityId = req.params.commodityId;
    const { name, price } = req.body;
  
    // 验证必填项
    if (!name && !price) {
      return res.status(400).json({ message: '商品名称和价格至少有一项是必填项' });
    }
  
    try {
      // 如果提供了新的商品名称，检查名称是否已存在
      if (name) {
        const [rows] = await pool.query('SELECT * FROM commodity WHERE name = ? AND id != ?', [name, commodityId]);
        if (rows.length > 0) {
          return res.status(409).json({ message: '商品名称已存在' });
        }
      }
  
      // 调试：打印要更新的数据
      console.log('Updating data:', {
        commodityId,
        name,
        price
      });
  
      // 构造更新语句
      let updateFields = [];
      let updateValues = [];
  
      if (name) {
        updateFields.push('name = ?');
        updateValues.push(name);
      }
  
      if (price !== undefined) { // 考虑到价格可能为 0
        updateFields.push('price = ?');
        updateValues.push(price);
      }
  
      updateValues.push(commodityId);
  
      const updateQuery = `UPDATE commodity SET ${updateFields.join(', ')} WHERE id = ?`;
  
      // 更新商品信息
      const [result] = await pool.query(updateQuery, updateValues);
  
      console.log('Update result:', result); // 打印更新结果
  
      if (result.affectedRows === 0) {
        return res.status(404).json({ message: '商品不存在' });
      }
  
      // 查询更新后的商品信息
      const [commodityRows] = await pool.query('SELECT * FROM commodity WHERE id = ?', [commodityId]);
      if (commodityRows.length === 0) {
        return res.status(500).json({ message: '商品信息获取失败' });
      }
  
      const commodity = commodityRows[0];
  
      // 返回更新后的商品信息
      res.status(200).json({
        message: '商品信息更新成功',
        commodity: {
          id: commodity.id,
          name: commodity.name,
          price: commodity.price
        }
      });
    } catch (err) {
      // 捕获并返回详细的错误信息
      let errorMessage;
      if (err.code === 'ER_DUP_ENTRY') {
        errorMessage = '商品名称已存在';
      } else if (err.code === 'ER_BAD_NULL_ERROR') {
        errorMessage = '缺少必填字段';
      } else if (err.code === 'ER_TRUNCATED_WRONG_VALUE') {
        errorMessage = '字段值格式错误';
      } else {
        errorMessage = '数据库查询错误';
      }
      console.error('Database error:', err); // 打印完整的错误信息
      res.status(500).json({ message: errorMessage, error: err.message });
    }
  },

  // 查询 commodity 数据
  getCommodities: async (req, res) => {
    const { name = '', category, activity } = req.query;
    const category_id = category ? parseInt(category) : null;
    const activity_id = activity ? parseInt(activity) : null;
  
    try {
      let query = `
        SELECT c.*, sa.activity_name AS special_activity_name 
        FROM commodity c
        LEFT JOIN special_activity sa ON c.special_activity_id = sa.id
        WHERE c.name LIKE ?
      `;
      const params = [`%${name}%`];  // 模糊查询
  
      if (category_id) {
        query += ' AND c.category_id = ?';
        params.push(category_id);
      }
      if (activity_id) {
        query += ' AND c.special_activity_id = ?';
        params.push(activity_id);
      }
  
      console.log('SQL Query:', query);
      console.log('Params:', params);
  
      const [rows] = await pool.query(query, params);
      res.json(rows);
    } catch (err) {
      res.status(500).json({ message: '数据库查询错误', error: err });
    }
  },
};